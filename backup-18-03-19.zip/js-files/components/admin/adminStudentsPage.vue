<template>
    <div class="container is-centered">
        <h1>  {{ msg }} </h1>
    </div>
</template>
<script>
    export default{
        data(){
          return{
            msg: 'this is admin page that can show all students and can add new student to database'
          }
        }
    }
</script>
