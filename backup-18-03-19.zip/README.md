# Grupp Arbete

> Schedule Project using Vue + SQLITE3 + express

## Build Setup

``` bash
# install dependencies
npm install

# Run the Webpack on index.html
npm run start
